package com.cognizant.springlearn.controller;

import java.util.List;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.SpringLearnApplication;

@RestController
public class CountryController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
	
	@Autowired
	private CountryService countryService;
	
	CountryController(){
		LOGGER.info("Country controller Constructor");
	}
	
	@GetMapping("/country")
	public Country getCountryIndia() {
		LOGGER.info("start");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("in", Country.class);
		 return country;
	}
	
	@GetMapping("/countries")
	public List<Country> getAllCountries() {
		LOGGER.info("start");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries =  context.getBean("countryList", java.util.ArrayList.class);
		 return countries;
	}
	
	@GetMapping("/countries/{code}")
	public Country getCountry(@PathVariable(value = "code") String code) throws CountryNotFoundException{
		
		LOGGER.debug(code.toString());
		Country country = countryService.getCountry(code);
		return country;
	}
}
