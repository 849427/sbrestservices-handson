package com.cognizant.springlearn.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@Component
public class CountryService {
	
	public Country getCountry(String code) throws CountryNotFoundException{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries =  context.getBean("countryList", java.util.ArrayList.class);
		for(Country country : countries) {
			if(country.getCode().equalsIgnoreCase(code)) {
				return country;
			}
		}
		throw new CountryNotFoundException("Country not found");
		
	}
}
