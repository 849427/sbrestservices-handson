package com.cognizant.springlearn.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.springlearn.employee.*;

@Service
public class EmployeeService {
	
	
	
	@Autowired
	EmployeeDao employeeDao;
	
	@Transactional
	public ArrayList<Employee> getAllEmployees(){
		System.out.println("calling");
		return employeeDao.getAllEmployees(); 
	}
}
