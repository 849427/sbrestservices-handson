package com.cognizant.springlearn.employee;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.SpringLearnApplication;

@Component
public class EmployeeDao {
		
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

	static ArrayList<Employee> EMPLOYEE_LIST = new ArrayList<Employee>();
	
	public EmployeeDao() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		EMPLOYEE_LIST =  context.getBean("employeeList", java.util.ArrayList.class);
	}
	
	public ArrayList<Employee> getAllEmployees(){
		return EMPLOYEE_LIST;
	}
}
