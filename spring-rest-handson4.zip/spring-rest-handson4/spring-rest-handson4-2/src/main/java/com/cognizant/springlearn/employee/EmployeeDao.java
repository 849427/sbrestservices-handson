package com.cognizant.springlearn.employee;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.service.EmployeeService;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;

@Component
public class EmployeeDao {
		
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

	 ArrayList<Employee> EMPLOYEE_LIST = new ArrayList<Employee>();
	
	
	
	public EmployeeDao() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		EMPLOYEE_LIST =  context.getBean("employeeList", java.util.ArrayList.class);
	}
	
	public ArrayList<Employee> getAllEmployees(){
		return EMPLOYEE_LIST;
	}
	
	
public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException{
		for(Employee e : EMPLOYEE_LIST) {
			if(e.geteId() == employee.geteId()) {
				e.seteName(employee.geteName());
				e.setPermanent(employee.isPermanent());
				e.setSalary(employee.getSalary());
				e.setDateOfBirth(employee.getDateOfBirth());
				return e;
			}
		}
		throw new EmployeeNotFoundException("Employee not found");
		
	}

public boolean deleteEmployee(int eId) throws EmployeeNotFoundException{
	for(Employee e : EMPLOYEE_LIST) {
		if(e.geteId() == eId) {
		
			return EMPLOYEE_LIST.remove(e);
		}
	}
	throw new EmployeeNotFoundException("Employee not found");
	
}
}
