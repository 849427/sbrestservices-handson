package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cognizant.springlearn.employee.*;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;

@Service
public class EmployeeService {
	
	
	@Autowired
	EmployeeDao employeeDao;
	
	@Transactional
	public ArrayList<Employee> getAllEmployees(){
		return employeeDao.getAllEmployees(); 
	}
	
	public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException {
		
		return employeeDao.updateEmployee(employee);
		
	}
	
	public boolean deleteEmployee(int eId) throws EmployeeNotFoundException {
		
		return employeeDao.deleteEmployee(eId);
		
	}

}
