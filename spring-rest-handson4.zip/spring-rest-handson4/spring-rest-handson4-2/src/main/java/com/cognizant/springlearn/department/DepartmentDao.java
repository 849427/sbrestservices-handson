package com.cognizant.springlearn.department;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.employee.Employee;

@Component
public class DepartmentDao {

	static ArrayList<Department> DEPARTMENT_LIST = new ArrayList<Department>();
	
	public DepartmentDao() {
		ApplicationContext context = new ClassPathXmlApplicationContext("department.xml");
		DEPARTMENT_LIST =  context.getBean("departmentList", java.util.ArrayList.class);
	}
	
	public ArrayList<Department> getAllDepartments(){
		return DEPARTMENT_LIST;
	}
}
