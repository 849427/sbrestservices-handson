package com.cognizant.springlearn.skill;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

public class Skill {
	
	@NotNull
	@NumberFormat(style = Style.NUMBER)
	private int sId;
	
	@NotNull
	@NotBlank
	@Size(min=1,max=30,message = "Skill Name should be 1 to 30 characters long")
	private String sName;
}
