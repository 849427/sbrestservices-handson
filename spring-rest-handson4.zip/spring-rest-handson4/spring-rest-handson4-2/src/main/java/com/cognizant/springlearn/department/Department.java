package com.cognizant.springlearn.department;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

public class Department {
		
	@NotNull
	@NumberFormat(style = Style.NUMBER)
	private int dId;
	
	@NotNull
	@NotBlank
	@Size(min=1,max=30,message="Department Name should be 1 to 30 characters long")
	private String dName;
	
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	@Override
	public String toString() {
		return "Department [dId=" + dId + ", dName=" + dName + "]";
	}
	
	
}
